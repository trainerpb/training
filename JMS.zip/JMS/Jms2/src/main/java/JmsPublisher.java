import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class JmsPublisher {

	private String clientId;
	private String topicName;
	public JmsPublisher(String clientId, String topic) {
		super();
		this.clientId = clientId;
		this.topicName = topic;
	}

	private Connection connection;
	private Session session;
	
	private MessageProducer messageProducer;
	
	public void create()
		      throws JMSException {
		    

		    // create a Connection Factory
		    ConnectionFactory connectionFactory =
		        new ActiveMQConnectionFactory(
		            ActiveMQConnection.DEFAULT_BROKER_URL);

		    // create a Connection
		    connection = connectionFactory.createConnection();
//		    connection.setClientID(clientId);
		    connection.start();
		    

		    // create a Session
		    session =
		        connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

		    // create the Topic to which messages will be sent
		    Topic topic = session.createTopic(topicName);

		    // create a MessageProducer for sending messages
		    messageProducer = session.createProducer(topic);
		    messageProducer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
		  }

		  public void closeConnection() throws JMSException {
		    connection.close();
		  }

		  public void sendMessage(String msg)
		      throws JMSException {
		   

		    // create a JMS TextMessage
		    TextMessage textMessage = session.createTextMessage(msg);

		    // send the message to the topic destination
		    messageProducer.send(textMessage);

		    System.out.printf(clientId + ": sent message with text='{%s}'", msg);
		  }
	
}
