import java.util.Date;
import java.util.Scanner;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.zkoss.json.JSONObject;

public class JmsSender {
	

	public static void main(String[] args) throws Exception {
			JmsPublisher[] jmsPublishers=new JmsPublisher[4];
			jmsPublishers[0]=new JmsPublisher("c1", "Politics");
			jmsPublishers[1]=new JmsPublisher("c2", "Economy");
			jmsPublishers[2]=new JmsPublisher("c3", "Sports");
			jmsPublishers[3]=new JmsPublisher("c4", "Entertainment");
			for(JmsPublisher p:jmsPublishers) {
				p.create();
				System.out.println("JmsSender.main()");
			}
			
			while(true) {
				System.out.println("Enter Topic A=Politics B=Economy C=Sports D=Entertainment: ");
				String opt=readLine();
				System.out.println("Breaking News: ");
				String msg=readLine();
				switch (opt.toLowerCase()) {
				case "a":
					jmsPublishers[0].sendMessage(getJson(msg, new Date().toString(),"Politics"));
					break;
					
				case "b":
					jmsPublishers[1].sendMessage(getJson(msg, new Date().toString(),"Economy"));
					break;
					
				case "c":
					jmsPublishers[2].sendMessage(getJson(msg, new Date().toString(),"Sports"));
					break;
					
				case "d":
					jmsPublishers[3].sendMessage(getJson(msg, new Date().toString(),"Entertainment"));
					break;

				default:
					break;
				}
			}
			
	}

	public static String getJson(String msg, String ts, String topic) {
		JSONObject jObj = new JSONObject();
		jObj.put("msg", msg);
		//jObj.put("ts", ts);
		jObj.put("topic", topic);
		return jObj.toJSONString();
	}
	
	static Scanner scanner=new Scanner(System.in);
	public static String readLine() {
		return scanner.nextLine();
	}

}
