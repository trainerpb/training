
public class Main {

	public static void main(String[] args) throws Exception {
		
		JmsSubscriber[] jmsSubscribers=new JmsSubscriber[4];
		jmsSubscribers[0]=new JmsSubscriber("c1", "Politics");
		jmsSubscribers[1]=new JmsSubscriber("c2", "Economy");
		jmsSubscribers[2]=new JmsSubscriber("c3", "Sports");
		jmsSubscribers[3]=new JmsSubscriber("c4", "Entertainment");
		for(JmsSubscriber s:jmsSubscribers) {
			s.create();
		}
	}

}
