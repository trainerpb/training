import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import javax.jms.JMSException;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint(value="/jms/{username}")
public class WebSocketServer {
	private Session session;
	
   private Set<Session> sessions=new HashSet<Session>();
   {
	   JmsSubscriber[] jmsSubscribers=new JmsSubscriber[4];
		jmsSubscribers[0]=new JmsSubscriber("c1", "Politics",this);
		jmsSubscribers[1]=new JmsSubscriber("c2", "Economy",this);
		jmsSubscribers[2]=new JmsSubscriber("c3", "Sports",this);
		jmsSubscribers[3]=new JmsSubscriber("c4", "Entertainment",this);
		for(JmsSubscriber s:jmsSubscribers) {
			try {
				s.create();
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
   }
   
    @OnOpen
    public void onOpen(
      Session session, 
      @PathParam("username") String username) throws IOException {
  
        this.session = session;
        
        if(username.equalsIgnoreCase("user")) {
        	sessions.add(session);
        
       
       
    }
 
        
        
        
 
    
    
}
    
    @OnClose
    public void onClose(Session session) {
        System.out.println("onClose::" +  session.getId());
    }
    
    @OnMessage
    public void onMessage(String message, Session session) {
        System.out.println("onMessage::From=" + session.getId() + " Message=" + message);
        
        try {
            broadcast(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void broadcast( String message) {
		// TODO Auto-generated method stub
		for(Session s:sessions) {
			try {
				s.getBasicRemote().sendText(message);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@OnError
    public void onError(Throwable t) {
        System.out.println("onError::" + t.getMessage());
    }
    

}
