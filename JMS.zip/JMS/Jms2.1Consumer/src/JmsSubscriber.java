import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class JmsSubscriber implements MessageListener {
	private String clientId;
	private String topicName;
	private StringBuffer sb=new StringBuffer();
	
	public JmsSubscriber(String clientId, String topic) {
		super();
		this.clientId = clientId;
		this.topicName = topic;
	}

	private WebSocketServer server;
	public JmsSubscriber(String clientId, String topic, WebSocketServer webSocketServer) {
		// TODO Auto-generated constructor stub
		this.clientId = clientId;
		this.topicName = topic;
		this.server=webSocketServer;
	}

	private Connection connection;
	private Session session;
	
	private MessageConsumer messageConsumer;
	
	public void create()
		      throws JMSException {
		    

		    // create a Connection Factory
		    ConnectionFactory connectionFactory =
		        new ActiveMQConnectionFactory(
		            ActiveMQConnection.DEFAULT_BROKER_URL);

		    // create a Connection
		    connection = connectionFactory.createConnection();
//		    connection.setClientID(clientId);
		    connection.start();

		    // create a Session
		    session =
		        connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

		    // create the Topic to which messages will be sent
		    Topic topic = session.createTopic(topicName);

		    // create a MessageProducer for sending messages
		    messageConsumer = session.createConsumer(topic);
		    messageConsumer.setMessageListener(this);
		  }

		  public void closeConnection() throws JMSException {
		    connection.close();
		  }

		public void onMessage(Message message) {
			// TODO Auto-generated method stub
			if(message instanceof TextMessage) {
				String x;
				try {
					x = ((TextMessage) message).getText();
					sb.append(x);
					System.out.println("Received Nws"+this.topicName+" ---> "+sb.toString());
					server.broadcast(x);
				} catch (JMSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
		}

}
