import java.util.Scanner;

import javax.jms.JMSException;

public class Main {

	public static void main(String[] args) {
		while(true) {
			System.out.println("Enter your mobile number: ");
			String mobile=readLine();
			System.out.println("Enter message post transation :");
			String msg=readLine();
			System.out.println("Confirm ?");
			String opt=readLine();
			if(opt.toLowerCase().startsWith("yes")||opt.equalsIgnoreCase("Y")) {
				try {
					P2P_Sender .sendMessage(msg, mobile);
				} catch (JMSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}
	static Scanner scanner=new Scanner(System.in);
	public static String readLine() {
		return scanner.nextLine();
	}
}
